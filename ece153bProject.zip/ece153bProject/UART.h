#ifndef __STM32L476G_DISCOVERY_UART_H
#define __STM32L476G_DISCOVERY_UART_H

#include "stm32l476xx.h"

#define BufferSize 1

void UART2_Init(void);
void Bluetooth_GPIO_Init(void);
void USB_GPIO_Init(void);

void USART_Init(USART_TypeDef* USARTx);

void USART2_IRQHandler(void);

void USART_Write(uint8_t *buffer, uint32_t nBytes);
uint8_t USART_Read();
void USART_Delay(uint32_t us);
void USART_IRQHandler(uint8_t *buffer, uint32_t * pRx_counter);

#endif
