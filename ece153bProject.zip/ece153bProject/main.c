#include "stm32l476xx.h"

#include "LED.h"
#include "SysClock.h"
#include "I2C.h"
#include "LCD.h"
#include "UART.h"

#include <string.h>
#include <stdio.h>

// Initializes USART for each part of Lab 3A
// part = 1: UART Communication with Termite
// part = 2: Bluetooth Communication with Phone
void Init_USARTx(int part) {
	if(part == 1) {
		UART2_Init();
		UART2_GPIO_Init();
		USART_Init(USART2);
	} else if(part == 2) {
		UART1_Init();
		UART1_GPIO_Init();
		USART_Init(USART1);
	} else {
		// Do nothing...
	}
}

int main(void) {
	System_Clock_Init(); // Switch System Clock = 80 MHz
	LED_Init();

	LCD_Initialization();
	LCD_Clear();
	
	// Initialize I2C
	I2C_GPIO_Init();
	I2C_Initialization();

	int i;
	char message[6];
	uint8_t SlaveAddress;
	uint8_t Data_Receive[6];
	uint8_t Data_Send[6];
	
	// Initialize UART -- change the argument depending on the part you are working on
	Init_USARTx(2);
	
	char rxByte;
	while(1) {
		// Determine Slave Address
		//
		// Note the "<< 1" must be present because bit 0 is treated as a don't care in 7-bit addressing mode
		SlaveAddress = ((uint8_t)0b1001000) << 1; // is it ok if its in hex ?
		
		// TODO - Get Temperature
		Data_Send = 0x00; //00h is the command to send the data 
		I2C_SendData(I2C1, SlaveAddress,&Data_Send,1);
	
		// First, send a command to the sensor for reading the temperature
		// Next, get the measurement
		//Read //stores as a 
		I2C_ReceiveData( I2C1,SlaveAddress,&Data_Receive,1);
		
		// convertng to a signed number
		
		sprintf(message,"%6d",Data_Receive);
		// TODO - Print Temperature to LCD
		LCD_DisplayString(message);
		// Some delay
		for(i = 0; i < 50000; ++i);

		scanf("%c", &rxByte);
		if(rxByte == 'Y' || rxByte == 'y')	{
			Red_LED_On();
			printf("The red LED has been turned on");
		}
		else if(rxByte == 'N' || rxByte == 'n')	{
			Red_LED_Off();
			printf("The red LED has been turned off");
		}
		else	{
			printf("Invalid input, please enter a valid command");
		}
	}
}
