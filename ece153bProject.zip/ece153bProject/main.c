#include "stm32l476xx.h"

#include "LED.h"
#include "SysClock.h"
#include "I2C.h"
#include "LCD.h"
#include "UART.h"

#include <string.h>
#include <stdio.h>

uint32_t volatile currentValue = 0;
uint32_t volatile lastValue = 0;
uint32_t volatile overflowCount = 0;
uint32_t volatile timeInterval = 0;
char rxByte[1];


void Input_Capture_Setup() {
	//Enable the clock of the PA0
	RCC ->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
	//set PA0 to alternative function mode (10)
	GPIOA -> MODER &= ~GPIO_MODER_MODE0_0; 
	GPIOA -> MODER |=  GPIO_MODER_MODE0_1;  

	//we are PA0 so we use AFR"L" (0-7) set to alternative function 2 
	GPIOA -> AFR[0] |= GPIO_AFRL_AFSEL0_1;

	//No pull up no pull down (00)
	GPIOA -> PUPDR &= ~GPIO_PUPDR_PUPDR0_0; 
	GPIOA -> PUPDR &= ~GPIO_PUPDR_PUPDR0_1; 

	//enabling timer 5 in regsiter 1
	RCC-> APB1ENR1 |= RCC_APB1ENR1_TIM5EN; 

	//enable auto reload pre load, set auto reload value to 65535, and set the prescaler
	// set ARR value (to maximum)
	TIM5->CR1 |= TIM_CR1_ARPE;
	TIM5->ARR = 65535;
	TIM5->PSC = 79; //79+1 = 80 80MHZ/80 = 1us per tick 

	//mapping value to TIM1
	//In the capture/compare mode register, set the input capture mode bits such that the input capture is mapped to timer input 1.
    //Note: CC2S bits are writable only when the channel is OFF (CC2E = ?0? in TIMx_CCER).
	//01: CC1 channel is configured as input, IC1 is mapped on TI1
	TIM5->CCMR1 |= TIM_CCMR1_CC1S_0;
	TIM5->CCMR1 &= ~TIM_CCMR1_CC1S_1;

	//In the capture/compare enable register, set bits to capture both rising/falling edges and enable capturing.
	//(11) The circuit is sensitive to both TIxFP1 rising and falling edges
	TIM5 -> CCER |= TIM_CCER_CC1NP;
	TIM5 -> CCER |= TIM_CCER_CC1P;
	//enable, 1: Capture enabled.
	TIM5 ->CCER |= TIM_CCER_CC1E;
	
	// #6 In the DMA/Interrupt enable register, enable both interrupt and DMA requests. 
	//DMA  Capture/Compare 1 DMA request enable (set to 1) 
	TIM5->DIER |= TIM_DIER_CC1DE;
	// enable the interrupt in compare and capture 1 
	TIM5 -> DIER |= TIM_DIER_CC1IE;

	//#7 Enable update generation in the event generation register.
  	TIM5 -> EGR |= TIM_EGR_UG;
	
	//#Enable and Clear the update interrupt flag
	TIM5->DIER |= TIM_DIER_UIE;
	TIM5->SR &= ~TIM_SR_UIF;
	TIM5->SR &= ~TIM_SR_CC1IF;
	
	//#9 Set the direction (UP) of the counter 0 = up 1= down   
	TIM5 -> CR1 &= ~TIM_CR1_DIR;
	//enable the counter in the control register. 
	TIM5 -> CR1 |= TIM_CR1_CEN;
	
	//#10 Initialize NVIC stuff and set priority to 2
	NVIC_EnableIRQ(TIM5_IRQn); //Enable interrupt in NVIC and set priority
	NVIC_SetPriority(TIM5_IRQn, 2);
}

void TIM5_IRQHandler(void) {
	// If overflow occurs (internal signal)
	//TIM4 Status register -> Update Interupt Flag 
	//? At overflow or underflow regarding the repetition counter value (update if repetition counter
	//0) and if the UDIS=0 in the TIMx_CR1 register
	
	if(TIM5->SR & TIM_SR_UIF)
	{
		overflowCount++;
		TIM5->SR &= ~TIM_SR_UIF;
	}
	//**Part 1
	//External signal 
	//Capture and Compare ` 
	if(TIM5->SR & TIM_SR_CC1IF) 
	{
	//The counter value has been captured in TIMx_CCR1 register (An edge has been
	//detected on IC1 which matches the selected polarity)
		//uint32_t temp = TIM4->CCR1;
		//currentValue = temp + 65535*overflowCount; // ARR value * #overflows  = number of tottal ticks elapsed
		//timeInterval = currentValue-lastValue;
		//lastValue = temp;
		//overflowCount = 0;
	
		//***Part2 
		//rising edge detector 
		if((GPIOA->IDR & GPIO_IDR_ID0)) 
		{
			lastValue= TIM5->CCR1;
			overflowCount = 0;
		}
		//falling edge detector 
		else if((GPIOA->IDR & GPIO_IDR_ID0) == 0) 
		{
			uint32_t temp = TIM5->CCR1;
			currentValue = temp + 65535*overflowCount;
			timeInterval = currentValue-lastValue;
		}
	}
	}
	


void Trigger_Setup() {
		//Enable the clock of the PE11 
	RCC ->AHB2ENR |= RCC_AHB2ENR_GPIOEEN;
	//set PE11 to alternative function mode (10)
	GPIOE -> MODER &= ~GPIO_MODER_MODE11_0;
	GPIOE -> MODER |=  GPIO_MODER_MODE11_1;  

	//we are PE11 so we use AFR"H" (0-7) set to alternative function 1 
	GPIOE -> AFR[1] |= GPIO_AFRH_AFSEL11_0;

	//No pull up no pull down (00)
	GPIOE -> PUPDR &= ~GPIO_PUPDR_PUPDR6_0;
	GPIOE -> PUPDR &= ~GPIO_PUPDR_PUPDR6_1;
	
	//Set the output type of PE11 to push-pull
	GPIOE->OTYPER &= ~GPIO_OTYPER_OT11;
	
	//Set PE11 to very high output speed
	GPIOE->OSPEEDR |= GPIO_OSPEEDR_OSPEED11;

	//enabling timer 4 in regsiter 1
	RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;

	//enable auto reload pre load, set auto reload value to 65535, and set the prescaler
	// set ARR value (to maximum)
	TIM1->PSC = 79; //79+1 = 80 80MHZ/80 = 1us per tick 
	TIM1->CR1 |= TIM_CR1_ARPE;
	TIM1->ARR = 65535;
	
	//Set CCR value that will trigger the sensor
	TIM1->CCR2 &= ~TIM_CCR2_CCR2;
	TIM1->CCR2 |= 2000;

	//In the capture/compare mode register, set the output control mode bits such that the timer is in PWM Mode 1 and enable the output compare preload.
    //Note: CC2S bits are writable only when the channel is OFF (CC2E = ?0? in TIMx_CCER).
	//01: CC1 channel is configured as input, IC1 is mapped on TI1
	TIM1->CCMR1 |= TIM_CCMR1_OC2PE;
	TIM1->CCMR1 &= ~TIM_CCMR1_OC2M;
	TIM1->CCMR1 |= TIM_CCMR1_OC2M_2;
	TIM1->CCMR1 |= TIM_CCMR1_OC2M_1;
	
	//Set output polarity for Ch2
	TIM1->CCER &= ~TIM_CCER_CC2NP;
	
	//Enable capture compare of Ch2
	TIM1->CCER |= TIM_CCER_CC2E;
	TIM1->CCER |= TIM_CCER_CC2NE;
	
	//Handle break and dead-time register for run mode
	TIM1->BDTR |= (TIM_BDTR_MOE | TIM_BDTR_OSSR);

	//#7 Enable update generation in the event generation register.
  TIM1->EGR |= TIM_EGR_UG; 
	
	//#Enable and Clear the update interrupt flag
	TIM1->DIER |= TIM_DIER_UIE;
	TIM1->SR |= TIM_SR_UIF;
	
	//#9 Set the direction (DOWN) of the counter 0 = up 1= down   
	TIM1 -> CR1 |= TIM_CR1_DIR;
	//enable the counter in the control register. 
	TIM1 -> CR1 |= TIM_CR1_CEN;
}

void USART2_IRQHandler() 	{ //set up interupt ####
	USART_IRQHandler(rxByte, BufferSize); //Write to rxByte if new data occurs
	//Handle sending things out based on this
	
}

// Initializes USART for each part of Lab 3A
// part = 1: UART Communication with Termite
// part = 2: Bluetooth Communication with Phone
void Init_USARTx() {
		UART2_Init();
		USB_GPIO_Init();
		USART_Init(USART2);
}

int main(void) {
	
	System_Clock_Init(); // Switch System Clock = 80 MHz
	
	// Initialize I2C
	I2C_GPIO_Init();
	I2C_Initialization();
	
	Input_Capture_Setup();
	Trigger_Setup();

	LCD_Initialization();
	LCD_Clear();

	char message[6];
	uint8_t SlaveAddress = ((uint8_t)0b0000100) << 1;
	uint8_t Data_Receive;
	uint8_t Data_Send = 0x00;
	
	// Initialize USART2
	Init_USARTx();
	
	while(1) { //use in 
			scanf("%c", rxByte);
			if((int)timeInterval/147 < 20)	{
				if(rxByte[0] == 'o')	{
					Data_Send = 0x00;
					printf("The lamp has been turned off");
				}
				else if(rxByte[0] == 'l')	{
					Data_Send = 0x01;
					printf("The lamp has been turned on to low mode");
				}
				else if(rxByte[0] == 'h')	{
					Data_Send = 0x02;
					printf("The lamp has been turned on to high mode");
				}
				else	{
					printf("Invalid input, please enter a valid command");
				}
			}
			else	{
				Data_Send = 0x00;
				printf("You have left, lamp has turned off");
			}
		
		I2C_SendData(I2C1, SlaveAddress,&Data_Send,1);
	}
}
